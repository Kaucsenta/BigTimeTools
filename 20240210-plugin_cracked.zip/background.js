// Function to fetch data from the API and store it
function fetchData() {
  const url = 'https://api.openloot.com/v2/market/items/in-game?gameId=56a149cf-f146-487a-8a1c-58dc9ff3a15c&page=1&pageSize=500&tags=space';

  fetch(url)
    .then(response => response.json())
    .then(data => {
      const items = data.items || [];
      const spaceData = items.map(item => {
        const issuedId = item.issuedId;
        const archetypeId = item.metadata ? item.metadata.archetypeId : null;
        let lastCrackedHourGlassDropTime = null;
        if (item.extra && item.extra.attributes) {
          const lastCrackedAttribute = item.extra.attributes.find(attr => attr.name === 'LastCrackedHourGlassDropTime');
          lastCrackedHourGlassDropTime = lastCrackedAttribute ? lastCrackedAttribute.value : null;
        }
        return { issuedId, archetypeId, lastCrackedHourGlassDropTime };
      }).filter(item => item.lastCrackedHourGlassDropTime !== null);

      // Store the data using Chrome's storage API
      chrome.storage.local.set({ 'spaceData': spaceData }, function() {
        console.log('Hourglass data is stored.');
      });
    })
    .catch(error => console.error('Error fetching data:', error));
}

// Function to fetch total TimeWarden items from the API and store it
function fetchTimeWardenTotalItems() {
  const url = 'https://api.openloot.com/v2/market/items/in-game?gameId=56a149cf-f146-487a-8a1c-58dc9ff3a15c&nftTags=NFT.Workshop.TimeWarden&page=1&pageSize=50&sort=name%3Aasc';

  fetch(url)
    .then(response => response.json())
    .then(data => {
      const totalItems = data.totalItems || 0;

      // Store the total number of TimeWarden items using Chrome's storage API
      chrome.storage.local.set({ 'timeWardenTotalItems': totalItems }, function() {
        console.log('TimeWarden total items is stored.');
      });
    })
    .catch(error => console.error('Error fetching TimeWarden total items:', error));
}

// Call fetchData when the background script loads and when a refresh message is received
// Call fetchData when the background script loads
fetchData();
fetchTimeWardenTotalItems();
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "refreshData") {
    // Call fetchData when the background script loads
fetchData();
    fetchTimeWardenTotalItems();
    sendResponse({status: 'success'});
  }
});
