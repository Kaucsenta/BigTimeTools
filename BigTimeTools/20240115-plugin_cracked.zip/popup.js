// Function to calculate time elapsed since lastCrackedHourGlassDropTime
function timeRemainingTo48Hours(dateString) {
  const lastCrackedDate = new Date(dateString);
  const now = new Date();
  const remaining = lastCrackedDate.getTime() + (48 * 60 * 60 * 1000) - now.getTime();
  const totalMinutes = Math.floor(remaining / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${hours}:${minutes.toString().padStart(2, '0')}`; // Returns time remaining to reach 48:00
}

// Function to create a table row with three cells
function createRow(issuedId, archetypeId, lastCrackedHourGlassDropTime) {
  const tr = document.createElement('tr');
  // tr.dataset.archetypeId = archetypeId;
  // tr.dataset.lastCrackedHourGlassDropTime = lastCrackedHourGlassDropTime;
  const tdIssuedId = document.createElement('td');
  const link = document.createElement('a');
  link.href = `https://openloot.com/items/BT0/${archetypeId.replace('BT0_', '')}/issue/${issuedId}`;
  link.textContent = issuedId;
  link.target = '_blank'; // Open link in a new tab
  tdIssuedId.appendChild(link);
  const tdLastCracked = document.createElement('td');
  tdLastCracked.textContent = lastCrackedHourGlassDropTime;
  const tdTimeElapsed = document.createElement('td');
  const remainingText = timeRemainingTo48Hours(lastCrackedHourGlassDropTime);
  tdTimeElapsed.textContent = remainingText;
  const checkmark = document.createElement('span');
  checkmark.classList.add('checkmark');
  checkmark.innerHTML = '&#10004;&nbsp;'; // Unicode checkmark symbol with a space
  const hours = parseInt(remainingText.split(':')[0]);
  const minutes = parseInt(remainingText.split(':')[1]);
  if (hours <= 0 && minutes <= 0) {
    tdIssuedId.prepend(checkmark);
    incrementReadyCount();
  }
  tr.appendChild(tdIssuedId);
  tr.appendChild(tdLastCracked);
  tr.appendChild(tdTimeElapsed);
  return tr;
}

// Function to increment the ready count
function incrementReadyCount() {
  const readyCountElement = document.getElementById('ready-count');
  const nextPickupElement = document.getElementById('next-pickup');
  if (readyCountElement) {
    let minTimeRemaining = null;
    document.querySelectorAll('tbody tr').forEach(row => {
      const timeRemainingText = row.cells[2].textContent;
      const [hours, minutes] = timeRemainingText.split(':').map(n => parseInt(n, 10));
      const timeRemaining = hours * 60 + minutes;
      if (minTimeRemaining === null || timeRemaining < minTimeRemaining) {
        minTimeRemaining = timeRemaining;
      }
    });
    const minHours = Math.floor(minTimeRemaining / 60);
    const minMinutes = minTimeRemaining % 60;
    const nextPickupText = `${minHours}:${minMinutes.toString().padStart(2, '0')}`;
    const checkmarks = document.querySelectorAll('.checkmark').length;
    readyCountElement.textContent = `Ready for pickup: ${checkmarks}`;
    nextPickupElement.textContent = `Next pickup in: ${nextPickupText}`;
  } else {
    console.error('Ready count element not found');
  }
}

// Function to build the table and insert it into the popup
function buildTable(spaceData) {
  const table = document.createElement('table');
  const thead = document.createElement('thead');
  const trHead = document.createElement('tr');
  const thIssuedId = document.createElement('th');
  thIssuedId.textContent = 'Issued ID';
  const thLastCracked = document.createElement('th');
  thLastCracked.textContent = 'Last Cracked';
  const thTimeRemaining = document.createElement('th');
  thTimeRemaining.textContent = 'Next pickup in';
  trHead.appendChild(thIssuedId);
  trHead.appendChild(thLastCracked);
  trHead.appendChild(thTimeRemaining);
  thead.appendChild(trHead);
  table.appendChild(thead);

  const tbody = document.createElement('tbody');
  // Function to compare elapsed time between two dates
  function compareElapsedTime(a, b) {
    const dateA = new Date(a.lastCrackedHourGlassDropTime);
    const dateB = new Date(b.lastCrackedHourGlassDropTime);
    return dateA - dateB;
  }

  // Calculate the total number of rows
  const totalSpaces = spaceData.length;
  chrome.storage.local.get('timeWardenTotalItems', function(storageData) {
    const timeWardenTotalItems = storageData.timeWardenTotalItems || 0;

    const wardensNeeded = Math.ceil(totalSpaces / 3.208);
    const wardensNeededApprox = wardensNeeded - timeWardenTotalItems;
    document.getElementById('totalSpaces').textContent = `${totalSpaces} Spaces`;
    document.getElementById('wardensNeeded').textContent = `You have ${timeWardenTotalItems} wardens, might need ${wardensNeededApprox} more`;
  });

  // Sort the data by elapsed time before creating rows
  spaceData.sort(compareElapsedTime).forEach(item => {
    const tr = createRow(item.issuedId, item.archetypeId, item.lastCrackedHourGlassDropTime);
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);

  document.getElementById('loadingMessage').style.display = 'none';
  document.body.appendChild(table);
  // Update the ready count and next pickup time when building the table
  incrementReadyCount();
}

// Function to update the potential revenue display
function updatePotentialRevenue(spaceData, avgCrackedDrops) {
  avgCrackedDrops = avgCrackedDrops || 1.5; // Use the provided avgCrackedDrops or default to 1.5
  const totalSpaces = spaceData.length;
  const bigTimePriceElement = document.getElementById('bigTimePriceAmount');
  if (bigTimePriceElement && bigTimePriceElement.textContent) {
    const bigTimePrice = parseFloat(bigTimePriceElement.textContent.replace('$', ''));
    if (!isNaN(bigTimePrice)) {
      const monthlyRevenuePerSpace = (avgCrackedDrops/2) * 12 * bigTimePrice * 30;
      const potentialRevenue = totalSpaces * monthlyRevenuePerSpace;
      const potentialRevenueElement = document.createElement('div');
      potentialRevenueElement.id = 'potentialRevenue';
      potentialRevenueElement.textContent = `Revenue: $${potentialRevenue.toFixed(2)}`;
      const perSpaceRevenueElement = document.createElement('div');
      perSpaceRevenueElement.id = 'perSpaceRevenue';
      perSpaceRevenueElement.textContent = `Per Space: $${monthlyRevenuePerSpace.toFixed(2)}`;
      const perSpaceDetailsElement = document.createElement('div');
      perSpaceDetailsElement.id = 'perSpaceDetails';
      const totalSpacesElement = document.getElementById('totalSpaces');
      if (totalSpacesElement) {
        const existingPotentialRevenueElement = document.getElementById('potentialRevenue');
        if (existingPotentialRevenueElement) {
          existingPotentialRevenueElement.textContent = potentialRevenueElement.textContent;
          const existingPerSpaceRevenueElement = document.getElementById('perSpaceRevenue');
          if (existingPerSpaceRevenueElement) {
            existingPerSpaceRevenueElement.textContent = perSpaceRevenueElement.textContent;
            const existingPerSpaceDetailsElement = document.getElementById('perSpaceDetails');
            if (existingPerSpaceDetailsElement) {
              existingPerSpaceDetailsElement.textContent = perSpaceDetailsElement.textContent;
            } else {
              existingPerSpaceRevenueElement.after(perSpaceDetailsElement);
            }
          } else {
            existingPotentialRevenueElement.after(perSpaceRevenueElement);
            perSpaceRevenueElement.after(perSpaceDetailsElement);
          }
        } else {
          totalSpacesElement.after(potentialRevenueElement);
          potentialRevenueElement.after(perSpaceRevenueElement);
          perSpaceRevenueElement.after(perSpaceDetailsElement);
          const avgCrackedDropsElement = document.createElement('a');
          avgCrackedDropsElement.id = 'avgCrackedDrops';
          avgCrackedDropsElement.href = '#'; // Placeholder href, can be updated to a relevant link if needed
          avgCrackedDropsElement.innerHTML = `Average Drops: <span class="link-style">${avgCrackedDrops}</span>`;
          perSpaceRevenueElement.after(avgCrackedDropsElement);
        }
      }
    }
  }
}

// Function to prompt for a new average drops value
function promptForAvgCrackedDrops() {
  chrome.storage.local.get(['avgCrackedDrops', 'spaceData'], function(storageData) {
    const currentAvgCrackedDrops = storageData.avgCrackedDrops || 1.5;
    const newAvgCrackedDrops = prompt('Enter new average drops:', currentAvgCrackedDrops);
    if (newAvgCrackedDrops !== null && !isNaN(parseFloat(newAvgCrackedDrops))) {
      chrome.storage.local.set({'avgCrackedDrops': parseFloat(newAvgCrackedDrops)}, function() {
        console.log('Average drops updated.');
        const avgCrackedDropsElement = document.getElementById('avgCrackedDrops');
        if (avgCrackedDropsElement) {
          avgCrackedDropsElement.innerHTML = `Average Drops: <span class="link-style">${newAvgCrackedDrops}</span>`;
          avgCrackedDropsElement.querySelector('.link-style').href = '#';
        }
        if (storageData.spaceData) {
          updatePotentialRevenue(storageData.spaceData, parseFloat(newAvgCrackedDrops));
        }
      });
    }
  });
}

// Function to fetch data from storage and build the table
function initPopup() {
  chrome.runtime.sendMessage({action: "refreshData"}, function(response) {
    if (response.status === 'success') {
      console.log('Data refreshed successfully.');
    }
  });
  chrome.storage.local.get('spaceData', function(data) {
    if (data.spaceData) {
      buildTable(data.spaceData);
      updatePotentialRevenue(data.spaceData);
    } else {
      document.getElementById('loadingMessage').textContent = 'No data available.';
    }
  });
  const avgCrackedDropsElement = document.getElementById('avgCrackedDrops');
  if (avgCrackedDropsElement) {
    avgCrackedDropsElement.addEventListener('click', promptForAvgCrackedDrops);
  }
}

// Function to refresh rows where time elapsed is greater than 48 hours
function refreshRowsWithTimeRemaining() {
  const rows = document.querySelectorAll('tbody tr');
  rows.forEach(row => {
    const elapsedCell = row.cells[2];
    if (elapsedCell) {
      const remainingText = elapsedCell.textContent;
      const hours = parseInt(remainingText.split(':')[0]);
      const minutes = parseInt(remainingText.split(':')[1]);
      if (hours <= 0 && minutes <= 0) {
        const issuedId = row.cells[0].textContent.trim();
        const archetypeId = row.dataset.archetypeId;
        const lastCrackedHourGlassDropTime = row.dataset.lastCrackedHourGlassDropTime;
        const updatedRow = createRow(issuedId, archetypeId, lastCrackedHourGlassDropTime);
        row.parentNode.replaceChild(updatedRow, row);
      }
    }
  });
}

// Function to refresh data and the table when the plugin button is clicked
const refreshDataOnClick = () => {
  chrome.runtime.sendMessage({action: "refreshData"}, function(response) {
    if (response.status === 'success') {
      initPopup();
    }
    console.log(response.status);
  });
}

// Function to update the countdown every second
const updateLeaderboardLink = () => {
  chrome.storage.local.get('leaderboardId', function(data) {
    const leaderboardId = data.leaderboardId;
    const leaderboardLinkElement = document.getElementById('leaderboardLink');
    if (leaderboardId && leaderboardId.trim() !== '') {
      leaderboardLinkElement.innerHTML = `<a href="https://lookerstudio.google.com/s/${leaderboardId}" target="_blank">Leaderboard</a>`;
    } else if (leaderboardId === '' || leaderboardId === null) {
      leaderboardLinkElement.innerHTML = `<a href="https://lookerstudio.google.com/reporting/fd3e27f7-568b-440e-896c-c2ee8dd5e1fa/page/pe1ZD" target="_blank">Leaderboard</a>`;
    }
  });
}

// Function to prompt for a new target date and time in UTC
const promptForTargetDate = () => {
  const targetDateString = prompt('Please enter the target date in UTC (YYYY-MM-DD):');
  if (targetDateString) {
    const newTargetDate = new Date(targetDateString + 'T23:59:59Z'); // Set time to 23:59:59 to indicate end of day in UTC
    if (!isNaN(newTargetDate.getTime())) {
      chrome.storage.local.set({'targetDate': newTargetDate.toISOString()}, function() {
        updateCountdown();
      });
    } else {
      alert('Invalid date format. Please enter a UTC date in the format YYYY-MM-DDTHH:MM');
    }
  }
};

function updateCountdown() {
  const countdownElement = document.getElementById('countdown');
  const targetDateElement = document.getElementById('targetDateDisplay');
  chrome.storage.local.get('targetDate', function(data) {
    const targetDate = new Date(data.targetDate || '2024-01-11T23:59:59Z');
    const now = new Date();
    const diff = targetDate - now;

    if (diff > 0) {
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / (1000 * 60)) % 60);
      const countdownText = `${days}d ${hours}h ${minutes}m`;
      countdownElement.textContent = countdownText;
      const utcYear = targetDate.getUTCFullYear();
      const utcMonth = (targetDate.getUTCMonth() + 1).toString().padStart(2, '0'); // +1 because getUTCMonth() returns 0-11
      const utcDay = targetDate.getUTCDate().toString().padStart(2, '0');
      const utcHours = targetDate.getUTCHours().toString().padStart(2, '0');
      const utcMinutes = targetDate.getUTCMinutes().toString().padStart(2, '0');
      const utcTargetDate = `${utcYear}-${utcMonth}-${utcDay} ${utcHours}:${utcMinutes} UTC`;
      targetDateElement.textContent = `${utcTargetDate}`;
    } else {
      countdownElement.textContent = 'The countdown has ended.';
      targetDateElement.textContent = 'Target Date Not set';
    }
  });
}

// Function to fetch and display the BigTime token price
const fetchBigTimePrice = () => {
  const url = 'https://api.coingecko.com/api/v3/simple/price?ids=big-time&vs_currencies=USD&include_24hr_change=true';
  fetch(url)
    .then(response => response.json())
    .then(data => {
      const price = data['big-time'].usd;
      const priceChange = data['big-time'].usd_24h_change;
      document.getElementById('bigTimePrice').innerHTML = `<a href="https://www.coingecko.com/en/coins/big-time" target="_blank">BigTime:</a>`;
      document.getElementById('bigTimePriceAmount').textContent = `$${price}`;
      document.getElementById('bigTimePriceChange').textContent = `${priceChange.toFixed(2)}%`;
      const priceChangeDiv = document.createElement('div');
      document.getElementById('bigTimePriceChange').style.color = priceChange >= 0 ? 'green' : 'red';
    chrome.storage.local.get('spaceData', function(data) {
      if (data.spaceData) {
        updatePotentialRevenue(data.spaceData);
      }
    });
    })
    .catch(error => {
      console.error('Error fetching BigTime price:', error);
      document.getElementById('bigTimePrice').textContent = 'BigTime: Error fetching price';
    });
}

// Function to update the UTC clock every second
const updateUTCClock = () => {
  const utcClockElement = document.getElementById('utcClock');
  if (utcClockElement) {
    const now = new Date();
    const utcYear = now.getUTCFullYear();
    const utcMonth = (now.getUTCMonth() + 1).toString().padStart(2, '0'); // +1 because getUTCMonth() returns 0-11
    const utcDay = now.getUTCDate().toString().padStart(2, '0');
    const utcHours = now.getUTCHours().toString().padStart(2, '0');
    const utcMinutes = now.getUTCMinutes().toString().padStart(2, '0');
    const utcSeconds = now.getUTCSeconds().toString().padStart(2, '0');
    const utcTime = `${utcYear}-${utcMonth}-${utcDay} ${utcHours}:${utcMinutes}:${utcSeconds} UTC`;
    utcClockElement.textContent = utcTime;
  }
};

// Initialize the UTC clock update interval
document.addEventListener('DOMContentLoaded', () => {
  setInterval(updateUTCClock, 1000); // Update the UTC clock every second
});

// Function to prompt for a new leaderboard ID
const promptForLeaderboardId = () => {
  const leaderboardId = prompt('Please enter the Leaderboard ID (leave blank to clear):');
  // Allow setting a blank ID
  if (leaderboardId !== null) {
    chrome.storage.local.set({'leaderboardId': leaderboardId.trim()}, function() {
      updateLeaderboardLink();
    });
  }
};
// Function to toggle the help video display
const toggleHelpVideo = () => {
  const helpVideo = document.getElementById('helpVideo');
  const videoContainer = document.getElementById('videoContainer');
  videoContainer.style.display = videoContainer.style.display === 'none' ? 'block' : 'none';
  const helpButton = document.getElementById('helpButton');
  helpButton.textContent = videoContainer.style.display === 'block' ? 'Hide Help' : 'Show Help';
};


// Initialize the popup when it is opened
document.addEventListener('DOMContentLoaded', async () => {
  fetchBigTimePrice(); // Fetch and display the BigTime token price
  initPopup();
  updateLeaderboardLink(); // Update the leaderboard link
  document.getElementById('editLeaderboardLink').addEventListener('click', promptForLeaderboardId);
  document.getElementById('editTargetDate').addEventListener('click', promptForTargetDate);
  const helpButton = document.getElementById('helpButton');
  helpButton.textContent = 'Show Help'; // Set initial text for the help button
  helpButton.addEventListener('click', toggleHelpVideo);
  helpButton.textContent = 'Show Help'; // Set initial text for the help button
  document.getElementById('heading').addEventListener('click', refreshDataOnClick);
  await new Promise(resolve => setTimeout(resolve, 1000));
  updateCountdown(); // Update the countdown after a 1 second delay
  setInterval(updateCountdown, 60000); // Update the countdown every minute
  updateUTCClock(); // Update the UTC clock
  setInterval(updateUTCClock, 1000); // Update the UTC clock every second
});
