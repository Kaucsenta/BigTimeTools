window.avgCrackedDrops = window.avgCrackedDrops || 1; // Ensure avgCrackedDrops is globally accessible and defaults to 1
console.log('avgCrackedDrops 0: ', window.avgCrackedDrops)

// Function to calculate time elapsed since lastCrackedHourGlassDropTime
function timeRemainingToReady(dateString, spawnInterval) {
  const lastCrackedDate = new Date(dateString);
  const now = new Date();
  const remaining = lastCrackedDate.getTime() + (spawnInterval * 60 * 60 * 1000) - now.getTime();
  if (remaining <= 0) {
    return "Ready";
  } else {
    const totalMinutes = Math.floor(remaining / 60000);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours}:${minutes.toString().padStart(2, '0')}`; // Returns time remaining to reach spawnInterval:00
  }

}

function calculateWardensNeeded(totalSpaces, avgCrackedDrops) {
    console.log('avgCrackedDrops 1: ', avgCrackedDrops)
    const chgDismantleRatePerWarden = "TBD";
    const totalChgProduced = "TBD";
    // const chgDismantleRatePerWarden = 10 / (77 / 48); // CHG dismantled by a warden every 48 hours
    // const totalChgProduced = totalSpaces * window.avgCrackedDrops;
    return Math.ceil(totalChgProduced / chgDismantleRatePerWarden);
}

function calculateWardensNeededText(wardensNeeded = 0, timeWardenTotalItems = 0) {
  let wardensNeededText = '';
  wardensNeededText = "" // `You probably need ${wardensNeeded} wardens and have ${timeWardenTotalItems}`;
  return wardensNeededText;
}

// Function to create a table row with three cells
function createRow(item) {
  const { issuedId, archetypeId, lastCrackedHourGlassDropTime, rarity, size } = item;
  const tr = document.createElement('tr');
  // Retrieve spawnInterval from the item, which should have been stored in background.js
  const spawnInterval = item.spawnInterval || 'Unknown';
  // tr.dataset.archetypeId = archetypeId;
  // tr.dataset.lastCrackedHourGlassDropTime = lastCrackedHourGlassDropTime;
  // Add spawnInterval to the dataset for later use
  tr.dataset.spawnInterval = spawnInterval;
  const tdIssuedId = document.createElement('td');
  const link = document.createElement('a');
  link.href = `https://openloot.com/items/BT0/${archetypeId.replace('BT0_', '')}/issue/${issuedId}`;
  link.textContent = issuedId;
  link.target = '_blank'; // Open link in a new tab
  tdIssuedId.appendChild(link);
  const tdLastCracked = document.createElement('td');
  tdLastCracked.textContent = lastCrackedHourGlassDropTime;
  const tdTimeElapsed = document.createElement('td');
  const remainingText = timeRemainingToReady(lastCrackedHourGlassDropTime, parseInt(tr.dataset.spawnInterval));
  tdTimeElapsed.textContent = remainingText;
  const tdRarity = document.createElement('td');
  tdRarity.textContent = rarity || 'Unknown';
  const tdSize = document.createElement('td');
  tdSize.textContent = size || 'Unknown';
  const tdSpawnInterval = document.createElement('td');
  tdSpawnInterval.textContent = spawnInterval;
  tdSpawnInterval.textContent = spawnInterval || 'Unknown';
  const checkmark = document.createElement('span');
  checkmark.classList.add('checkmark');
  checkmark.innerHTML = '&#10004;&nbsp;'; // Unicode checkmark symbol with a space
  if (remainingText === "Ready") {
    tdIssuedId.prepend(checkmark);
    incrementReadyCount();
  }

  tr.appendChild(tdIssuedId);
  tr.appendChild(tdLastCracked);
  tr.appendChild(tdTimeElapsed);
  tr.appendChild(tdRarity);
  tr.appendChild(tdSize);
  tr.appendChild(tdSpawnInterval);
  return tr;
}

// Function to increment the ready count
function incrementReadyCount() {
  const readyCountElement = document.getElementById('ready-count');
  const nextPickupElement = document.getElementById('next-pickup');
  if (readyCountElement) {
    let minTimeRemaining = null;
    document.querySelectorAll('tbody tr').forEach(row => {
      const timeRemainingText = row.cells[2].textContent;
      const [hours, minutes] = timeRemainingText.split(':').map(n => parseInt(n, 10));
      const timeRemaining = hours * 60 + minutes;
      if (minTimeRemaining === null || timeRemaining < minTimeRemaining) {
        minTimeRemaining = timeRemaining;
      }

    });
    let minHours = 0;
    let minMinutes = 0;
    let nextPickupText = 'Ready';
    if (minTimeRemaining !== null && !isNaN(minTimeRemaining) && minTimeRemaining > 0) {
      minHours = Math.floor(minTimeRemaining / 60);
      minMinutes = minTimeRemaining % 60;
      nextPickupText = `${minHours}:${minMinutes.toString().padStart(2, '0')}`;
    }

    const checkmarks = document.querySelectorAll('.checkmark').length;
    readyCountElement.textContent = `Ready for pickup: ${checkmarks}`;
    nextPickupElement.textContent = `Next pickup in: ${nextPickupText}`;
    if (nextPickupText === 'Ready') {
      nextPickupElement.classList.add('ready');
      const checkmarks = document.querySelectorAll('.checkmark').length;
      if (!window.nextPickupAlertShown) {
        const notification = new Notification('Cracked Hourglass Timer', {
          body: `Next pickup is ready! ${checkmarks} item(s) ready for pickup.`,
          icon: 'static/hourglass.png'
        });
        window.nextPickupAlertShown = true;
      }

    } else {
      nextPickupElement.classList.remove('ready');
    }

  } else {
    console.error('Ready count element not found');
  }

}

// Function to build the table and insert it into the popup
function buildTable(spaceData) {
  // Function to compare Next pickup time between two items
  function compareNextPickup(a, b) {
    const timeA = timeRemainingToReady(a.lastCrackedHourGlassDropTime, parseInt(a.spawnInterval));
    const timeB = timeRemainingToReady(b.lastCrackedHourGlassDropTime, parseInt(b.spawnInterval));
    const [hoursA, minutesA] = timeA.split(':').map(n => parseInt(n, 10));
    const [hoursB, minutesB] = timeB.split(':').map(n => parseInt(n, 10));
    const totalMinutesA = hoursA * 60 + minutesA;
    const totalMinutesB = hoursB * 60 + minutesB;
    return totalMinutesA - totalMinutesB;
  }

  const table = document.createElement('table');
  const thead = document.createElement('thead');
  const trHead = document.createElement('tr');
  const thIssuedId = document.createElement('th');
  thIssuedId.textContent = 'Issued ID';
  const thLastCracked = document.createElement('th');
  thLastCracked.textContent = 'Last Cracked';
  const thTimeRemaining = document.createElement('th');
  thTimeRemaining.textContent = 'Next pickup in';
  const thRarity = document.createElement('th');
  thRarity.textContent = 'Rarity';
  const thSize = document.createElement('th');
  thSize.textContent = 'Size';
  const thSpawnInterval = document.createElement('th');
  thSpawnInterval.textContent = 'Interval';
  trHead.appendChild(thIssuedId);
  trHead.appendChild(thLastCracked);
  trHead.appendChild(thTimeRemaining);
  trHead.appendChild(thRarity);
  trHead.appendChild(thSize);
  trHead.appendChild(thSpawnInterval);
  thead.appendChild(trHead);
  table.appendChild(thead);

  const tbody = document.createElement('tbody');
  // Function to compare elapsed time between two dates
  function compareElapsedTime(a, b) {
    const dateA = new Date(a.lastCrackedHourGlassDropTime);
    const dateB = new Date(b.lastCrackedHourGlassDropTime);
    return dateA - dateB;
  }

  // Calculate the total number of rows
  let totalSpaces;
  chrome.storage.local.get(['userTotalSpaces', 'spaceData'], function(storageData) {
    totalSpaces = storageData.userTotalSpaces || spaceData.length;
    console.log('totalSpaces: ', totalSpaces)
    console.log('storageData: ', storageData)
    document.getElementById('totalSpaces').textContent = `${totalSpaces} Space${totalSpaces > 1 ? 's' : ''}`;
    document.getElementById('totalSpacesInput').value = totalSpaces; // Update the Total Spaces input with the value from storage
  });
  chrome.storage.local.get('timeWardenTotalItems', function(storageData) {
    const timeWardenTotalItems = storageData.timeWardenTotalItems || 0;

    const wardensNeeded = "";
    // const wardensNeeded = calculateWardensNeeded(totalSpaces, window.avgCrackedDrops);
    let wardensNeededText = '';
    // wardensNeededText = `You probably need ${wardensNeeded} wardens and have ${timeWardenTotalItems}`;
    document.getElementById('totalSpaces').textContent = `${totalSpaces} Space${totalSpaces > 1 ? 's' : ''}`;
    document.getElementById('wardensNeeded').textContent = wardensNeededText;
  });

  // Sort the data by elapsed time before creating rows
  // Sort the data by Next pickup time before creating rows
  spaceData.sort(compareNextPickup).forEach(item => {
    const tr = createRow(item);
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);

  document.getElementById('loadingMessage').style.display = 'none';
  document.getElementById('tableContainer').appendChild(table);
  // Update the ready count and next pickup time when building the table
  incrementReadyCount();
}

// Function to update the potential revenue display
function updatePotentialRevenue(spaceData) {
  console.log('avgCrackedDrops: ', avgCrackedDrops)
  // document.getElementById('avgCrackedDropsValue').textContent = window.avgCrackedDrops || 1;
  let totalSpaces = spaceData.length;
  chrome.storage.local.get(['userTotalSpaces', 'timeWardenTotalItems'], function(storageData) {
    totalSpaces = storageData.userTotalSpaces || totalSpaces;
    const timeWardenTotalItems = storageData.timeWardenTotalItems || 0;
    const bigTimePriceElement = document.getElementById('bigTimePriceAmount');
    if (bigTimePriceElement && bigTimePriceElement.textContent) {
      const bigTimePrice = parseFloat(bigTimePriceElement.textContent.replace('$', ''));
      if (!isNaN(bigTimePrice)) {
        const monthlyRevenuePerSpace = (window.avgCrackedDrops/2) * 12 * bigTimePrice * 28;
        const potentialRevenue = totalSpaces * monthlyRevenuePerSpace;
        const potentialRevenueElement = document.getElementById('potentialRevenue');
        if (potentialRevenueElement) {
          potentialRevenueElement.textContent = `Revenue: $${potentialRevenue.toFixed(2)}`;
        }

        const perSpaceRevenueElement = document.getElementById('perSpaceRevenue');
        if (perSpaceRevenueElement) {
          perSpaceRevenueElement.textContent = `Per Space: $${monthlyRevenuePerSpace.toFixed(2)}`;
        }

        const wardensNeeded = calculateWardensNeeded(totalSpaces, window.avgCrackedDrops);
        const wardensNeededText = calculateWardensNeededText(wardensNeeded, timeWardenTotalItems);
        const wardensNeededElement = document.getElementById('wardensNeeded');
        if (wardensNeededElement) {
          wardensNeededElement.textContent = wardensNeededText;
        }

      }

    }

  });
  const bigTimePriceElement = document.getElementById('bigTimePriceAmount');
  if (bigTimePriceElement && bigTimePriceElement.textContent) {
    const bigTimePrice = parseFloat(bigTimePriceElement.textContent.replace('$', ''));
    if (!isNaN(bigTimePrice)) {
      const monthlyRevenuePerSpace = (window.avgCrackedDrops/2) * 12 * bigTimePrice * 28;
      const potentialRevenue = totalSpaces * monthlyRevenuePerSpace;
      const potentialRevenueElement = document.createElement('div');
      potentialRevenueElement.id = 'potentialRevenue';
      potentialRevenueElement.textContent = `Revenue: $${potentialRevenue.toFixed(2)}`;
      const perSpaceRevenueElement = document.createElement('div');
      perSpaceRevenueElement.id = 'perSpaceRevenue';
      perSpaceRevenueElement.textContent = `Per Space: $${monthlyRevenuePerSpace.toFixed(2)}`;
      const perSpaceDetailsElement = document.createElement('div');
      perSpaceDetailsElement.id = 'perSpaceDetails';
      const totalSpacesElement = document.getElementById('totalSpaces');
      if (totalSpacesElement) {
        const existingPotentialRevenueElement = document.getElementById('potentialRevenue');
        if (existingPotentialRevenueElement) {
          existingPotentialRevenueElement.textContent = potentialRevenueElement.textContent;
          const existingPerSpaceRevenueElement = document.getElementById('perSpaceRevenue');
          if (existingPerSpaceRevenueElement) {
            existingPerSpaceRevenueElement.textContent = perSpaceRevenueElement.textContent;
            const existingPerSpaceDetailsElement = document.getElementById('perSpaceDetails');
            if (existingPerSpaceDetailsElement) {
              existingPerSpaceDetailsElement.textContent = perSpaceDetailsElement.textContent;
            } else {
              existingPerSpaceRevenueElement.after(perSpaceDetailsElement);
            }

          } else {
            existingPotentialRevenueElement.after(perSpaceRevenueElement);
            perSpaceRevenueElement.after(perSpaceDetailsElement);
          }

        } else {
          totalSpacesElement.after(potentialRevenueElement);
          potentialRevenueElement.after(perSpaceRevenueElement);
          perSpaceRevenueElement.after(perSpaceDetailsElement);
          const avgCrackedDropsElement = document.createElement('a');
          avgCrackedDropsElement.id = 'avgCrackedDrops';
          avgCrackedDropsElement.href = '#'; // Placeholder href, can be updated to a relevant link if needed
          avgCrackedDropsElement.innerHTML = `Avg Drops: <span class="link-style">${avgCrackedDrops}</span>`;
          perSpaceRevenueElement.after(avgCrackedDropsElement);
        }

      }

    }

  }

}

// Function to prompt for a new average drops value
function promptForAvgCrackedDrops() {
  chrome.storage.local.get(['avgCrackedDrops', 'spaceData'], function(storageData) {
    const currentAvgCrackedDrops = storageData.avgCrackedDrops || 1;
    const newAvgCrackedDrops = prompt('Enter new average drops:', currentAvgCrackedDrops);
    if (newAvgCrackedDrops !== null && !isNaN(parseFloat(newAvgCrackedDrops))) {
      chrome.storage.local.set({'avgCrackedDrops': parseFloat(newAvgCrackedDrops)}, function() {
        console.log('Average drops updated.');
        const avgCrackedDropsElement = document.getElementById('avgCrackedDrops');
        if (avgCrackedDropsElement) {
          avgCrackedDropsElement.innerHTML = `TBD`;
          // avgCrackedDropsElement.innerHTML = `<span class="link-style">${newAvgCrackedDrops}</span> CHG every 48H`;
          avgCrackedDropsElement.querySelector('.link-style').href = '#';
        }
        if (storageData.spaceData) {
          // updatePotentialRevenue(storageData.spaceData, parseFloat(newAvgCrackedDrops));
        }
      });
    }
  });
}

// Function to fetch data from storage and build the table
async function initPopup() {
  try {
    // Ensure fetchData is called and completed in background.js
    chrome.runtime.sendMessage({action: "refreshData", data: "space"}, function(response) {
      if (response.status === 'success') {
        console.log('Data refreshed successfully.');
      } else {
        console.error('Data refresh failed');
      }
    });
    chrome.storage.local.get('spaceData', function(data) {
      if (data.spaceData) {
        buildTable(data.spaceData);
        // updatePotentialRevenue(data.spaceData);
      } else {
        document.getElementById('loadingMessage').textContent = 'No data available.';
      }
    });
    chrome.storage.local.get(['avgCrackedDrops', 'spaceData'], function(data) {
      window.avgCrackedDrops = data.avgCrackedDrops || 1;
      document.getElementById('avgCrackedDropsInput').value = window.avgCrackedDrops;
      if (data.spaceData) {
        // updatePotentialRevenue(data.spaceData);
      }
    });
    const saveAvgCrackedDropsButton = document.getElementById('saveAvgCrackedDrops');
    saveAvgCrackedDropsButton.addEventListener('click', function() {
      const newAvgCrackedDrops = "TBD";
      // const newAvgCrackedDrops = parseFloat(document.getElementById('avgCrackedDropsInput').value);
      chrome.storage.local.set({'avgCrackedDrops': 'TBD'}, function() {
      // chrome.storage.local.set({'avgCrackedDrops': newAvgCrackedDrops}, function() {
        console.log('Average drops updated.');
        chrome.storage.local.get('spaceData', function(storageData) {
            window.avgCrackedDrops = "TBD";
            // window.avgCrackedDrops = newAvgCrackedDrops;
        // updatePotentialRevenue(storageData.spaceData);
        });
      });
    });
  } catch (error) {
    console.error(error);
  }
}

// Function to refresh rows where time elapsed is greater than 48 hours
function refreshRowsWithTimeRemaining() {
  const rows = document.querySelectorAll('tbody tr');
  rows.forEach(row => {
    const elapsedCell = row.cells[2];
    if (elapsedCell) {
      const remainingText = elapsedCell.textContent;
      const hours = parseInt(remainingText.split(':')[0]);
      const minutes = parseInt(remainingText.split(':')[1]);
      if (hours <= 0 && minutes <= 0) {
        const issuedId = row.cells[0].textContent.trim();
        const archetypeId = row.dataset.archetypeId;
        const lastCrackedHourGlassDropTime = row.dataset.lastCrackedHourGlassDropTime;
        const updatedRow = createRow(issuedId, archetypeId, lastCrackedHourGlassDropTime);
        row.parentNode.replaceChild(updatedRow, row);
      }
    }
  });
}

// Function to refresh data and the table when the plugin button is clicked
const refreshDataOnClick = () => {
  chrome.runtime.sendMessage({action: "refreshData"}, function(response) {
    if (response.status === 'success') {
      initPopup();
    }
    console.log(response.status);
  });
}

// Function to update the countdown every second
const updateLeaderboardLink = () => {
  chrome.storage.local.get('leaderboardId', function(data) {
    const leaderboardId = data.leaderboardId;
    const leaderboardLinkElement = document.getElementById('leaderboardLink');
    if (leaderboardId && leaderboardId.trim() !== '') {
      leaderboardLinkElement.innerHTML = `<a href="https://lookerstudio.google.com/s/${leaderboardId}" target="_blank">Leaderboard</a>`;
    } else if (leaderboardId === '' || leaderboardId === null) {
      leaderboardLinkElement.innerHTML = `<a href="https://lookerstudio.google.com/reporting/08c7bf7c-061e-4865-9c9e-9f4dbeb3a904/page/svBoD" target="_blank">Leaderboard</a>`;
    }
  });
}

// Function to prompt for a new target date and time in UTC
const promptForTargetDate = () => {
  const targetDateString = prompt('Please enter the target date in UTC (YYYY-MM-DD):');
  if (targetDateString) {
    const newTargetDate = new Date(targetDateString + 'T23:59:59Z'); // Set time to 23:59:59 to indicate end of day in UTC
    if (!isNaN(newTargetDate.getTime())) {
      chrome.storage.local.set({'targetDate': newTargetDate.toISOString()}, function() {
        updateCountdown();
      });
    } else {
      alert('Invalid date format. Please enter a UTC date in the format YYYY-MM-DDTHH:MM');
    }
  }
};

function updateCountdown() {
  const countdownElement = document.getElementById('countdown');
  const targetDateElement = document.getElementById('targetDateDisplay');
  chrome.storage.local.get('targetDate', function(data) {
    const targetDate = new Date(data.targetDate || '2024-01-11T23:59:59Z');
    const now = new Date();
    const diff = targetDate - now;

    if (data.targetDate && diff > 0) {
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diff / (1000 * 60)) % 60);
      const countdownText = `${days}d ${hours}h ${minutes}m`;
      countdownElement.textContent = countdownText;
      const utcYear = targetDate.getUTCFullYear();
      const utcMonth = (targetDate.getUTCMonth() + 1).toString().padStart(2, '0'); // +1 because getUTCMonth() returns 0-11
      const utcDay = targetDate.getUTCDate().toString().padStart(2, '0');
      const utcHours = targetDate.getUTCHours().toString().padStart(2, '0');
      const utcMinutes = targetDate.getUTCMinutes().toString().padStart(2, '0');
      const utcTargetDate = `${utcYear}-${utcMonth}-${utcDay} ${utcHours}:${utcMinutes} UTC`;
      targetDateElement.textContent = `${utcTargetDate}`;
    } else if (data.targetDate) {
      countdownElement.textContent = 'The countdown has ended.';
    } else {
      targetDateElement.textContent = 'No date set';
      countdownElement.textContent = '';
    }
  });
}

// Function to fetch and display the BigTime token price
const fetchBigTimePrice = () => {
  const url = 'https://api.coingecko.com/api/v3/simple/price?ids=big-time&vs_currencies=USD&include_24hr_change=true';
  fetch(url)
    .then(response => response.json())
    .then(data => {
      const price = data['big-time'].usd;
      const priceChange = data['big-time'].usd_24h_change;
      document.getElementById('bigTimePrice').innerHTML = `<a href="https://www.coingecko.com/en/coins/big-time" target="_blank">BigTime:</a>`;
      document.getElementById('bigTimePriceAmount').textContent = `$${price}`;
      document.getElementById('bigTimePriceChange').textContent = `${priceChange.toFixed(2)}%`;
      const priceChangeDiv = document.createElement('div');
      document.getElementById('bigTimePriceChange').style.color = priceChange >= 0 ? 'green' : 'red';
    chrome.storage.local.get('spaceData', function(data) {
      if (data.spaceData) {
        // updatePotentialRevenue(data.spaceData);
      }
    });
    })
    .catch(error => {
      console.error('Error fetching BigTime price:', error);
      document.getElementById('bigTimePrice').textContent = 'BigTime: Error fetching price';
    });
}

// Function to update the UTC clock every second
const updateUTCClock = () => {
  const utcClockElement = document.getElementById('utcClock');
  if (utcClockElement) {
    const now = new Date();
    const utcYear = now.getUTCFullYear();
    const utcMonth = (now.getUTCMonth() + 1).toString().padStart(2, '0'); // +1 because getUTCMonth() returns 0-11
    const utcDay = now.getUTCDate().toString().padStart(2, '0');
    const utcHours = now.getUTCHours().toString().padStart(2, '0');
    const utcMinutes = now.getUTCMinutes().toString().padStart(2, '0');
    const utcSeconds = now.getUTCSeconds().toString().padStart(2, '0');
    const utcTime = `${utcYear}-${utcMonth}-${utcDay} ${utcHours}:${utcMinutes}:${utcSeconds} UTC`;
    utcClockElement.textContent = utcTime;
  }
};

// Initialize the UTC clock update interval
window.addEventListener('load', () => {
  setInterval(updateUTCClock, 1000); // Update the UTC clock every second
  // Add event listener for the cog icon to toggle the config panel
  const configCog = document.getElementById('configCog');
  configCog.addEventListener('click', function(event) {
    toggleConfigPanel();
    event.stopPropagation(); // Prevent this click from being captured by the window event listener
  });
  // Add event listener to close the config panel when clicking outside
  window.addEventListener('click', function(event) {
    const configPanel = document.getElementById('configPanel');
    if (configPanel.style.width === '250px') {
      closeConfigPanel();
    }
  });
});

// Function to prompt for a new leaderboard ID
const promptForLeaderboardId = () => {
  const leaderboardId = prompt('Please enter the Leaderboard ID (leave blank to clear):');
  // Allow setting a blank ID
  if (leaderboardId !== null) {
    chrome.storage.local.set({'leaderboardId': leaderboardId.trim()}, function() {
      updateLeaderboardLink();
    });
  }
};
// Function to toggle the help video display and update the button text
function toggleHelpVideo() {
  const helpVideo = document.getElementById('helpVideo');
  const videoContainer = document.getElementById('videoContainer');
  if (videoContainer) {
    videoContainer.style.display = videoContainer.style.display === 'none' ? 'block' : 'none';
    const helpButton = document.getElementById('helpButton');
    helpButton.textContent = videoContainer && videoContainer.style.display === 'block' ? 'Hide Help' : 'Show Help';
  } else {
    console.error('Video container not found');
  }
  const helpButton = document.getElementById('helpButton');
  helpButton.textContent = videoContainer.style.display === 'block' ? 'Hide Help' : 'Show Help';
};


// Function to toggle the configuration panel
function toggleConfigPanel() {
  const configPanel = document.getElementById('configPanel');
  const configPanelContent = document.getElementById('configPanelContent');
  // Check if the panel is currently open or closed by checking the width
  const isPanelOpen = configPanel.style.width === '250px';
  // Set the width and opacity based on the current state
  configPanel.style.width = isPanelOpen ? '0' : '250px';
  configPanelContent.style.opacity = isPanelOpen ? 0 : 1;
}

// Function to close the configuration panel
function closeConfigPanel() {
  const configPanel = document.getElementById('configPanel');
  configPanel.style.width = '0';
  setTimeout(() => {
    configPanelContent.style.opacity = 0;
  }, 300); // Start fading out slightly before the panel finishes collapsing
}

// Initialize the popup when it is opened
document.addEventListener('DOMContentLoaded', () => {
  fetchBigTimePrice(); // Fetch and display the BigTime token price
  refreshDataAndInitPopup(); // Refresh data and initialize the popup
  updateLeaderboardLink(); // Update the leaderboard link
  addEventListeners(); // Add event listeners for buttons and inputs
  updateCountdown(); // Update the countdown after a 1 second delay
  setInterval(updateCountdown, 60000); // Update the countdown every minute
  updateUTCClock(); // Update the UTC clock
  setInterval(updateUTCClock, 1000); // Update the UTC clock every second
});

// Removed duplicate function declaration
function setInputValuesToCurrentSettings() {
  chrome.storage.local.get(['leaderboardId', 'targetDate', 'avgCrackedDrops', 'userTotalSpaces'], function(data) {
    const leaderboardIdInput = document.getElementById('leaderboardIdInput');
    const countdownDateInput = document.getElementById('countdownDateInput');
    const avgCrackedDropsInput = document.getElementById('avgCrackedDropsInput');
    const totalSpacesInput = document.getElementById('totalSpacesInput');

    if (leaderboardIdInput && data.leaderboardId !== undefined) {
      leaderboardIdInput.value = data.leaderboardId;
    }

    if (countdownDateInput && data.targetDate !== undefined) {
      const targetDate = new Date(data.targetDate);
      countdownDateInput.value = targetDate.toISOString().split('T')[0]; // Set the date part
    }

    if (avgCrackedDropsInput && data.avgCrackedDrops !== undefined) {
      // document.getElementById('avgCrackedDropsValue').textContent = data.avgCrackedDrops || 1;
      avgCrackedDropsInput.value = data.avgCrackedDrops;
    }

    if (totalSpacesInput && data.userTotalSpaces !== undefined) {
      totalSpacesInput.value = data.userTotalSpaces;
    } else if (totalSpacesInput) {
      totalSpacesInput.value = '';
    }

    // Update the Total Spaces input with the value from storage
    document.getElementById('totalSpaces').textContent = `Spaces:${data.userTotalSpaces || 0}`;

  });
}

// Function to refresh data and initialize the popup
function refreshDataAndInitPopup() {
  clearNextPickupData();

  chrome.runtime.sendMessage({action: "refreshData"}, function(response) {
    if (response.status === 'success') {
      initPopup();
    } else {
      console.error('Error refreshing data:', response.status);
    }
  });
}

// Function to clear the 'Next pickup' and 'Ready for pickup' data
function clearNextPickupData() {
  const nextPickupElement = document.getElementById('next-pickup');
  const readyCountElement = document.getElementById('ready-count');
  if (nextPickupElement) nextPickupElement.textContent = 'Next pickup in: ...';
  if (readyCountElement) readyCountElement.textContent = 'Ready for pickup: ...';
}

// Function to add event listeners for buttons and inputs
function addEventListeners() {
  chrome.storage.local.get('avgCrackedDrops', function(data) {
    window.avgCrackedDrops = data.avgCrackedDrops || 1;
    // document.getElementById('avgCrackedDropsValue').textContent = window.avgCrackedDrops;
  });
  document.getElementById('saveLeaderboardId').addEventListener('click', function() {
    const leaderboardId = document.getElementById('leaderboardIdInput').value;
    chrome.storage.local.set({'leaderboardId': leaderboardId.trim()}, function() {
      updateLeaderboardLink();
    });
  });
  document.getElementById('saveCountdownDate').addEventListener('click', function() {
    const targetDateString = document.getElementById('countdownDateInput').value;
    const newTargetDate = new Date(targetDateString + 'T23:59:59Z');
    if (!isNaN(newTargetDate.getTime())) {
      chrome.storage.local.set({'targetDate': newTargetDate.toISOString()}, function() {
        updateCountdown();
      });
    } else {
      alert('Invalid date format. Please enter a UTC date in the format YYYY-MM-DD');
    }
  });
  document.getElementById('saveTotalSpaces').addEventListener('click', function() {
    const totalSpaces = parseInt(document.getElementById('totalSpacesInput').value, 10);
    chrome.storage.local.set({'userTotalSpaces': totalSpaces}, function() {
      console.log('Total spaces updated.');
      // Update the displayed total spaces immediately
      document.getElementById('totalSpaces').textContent = `${totalSpaces} Space${totalSpaces > 1 ? 's' : ''}`;
      // Update the potential revenue and wardens needed display
      chrome.storage.local.get(['spaceData', 'avgCrackedDrops', 'timeWardenTotalItems'], function(storageData) {
        // updatePotentialRevenue(storageData.spaceData, storageData.avgCrackedDrops);
      });
    });
  });
  document.getElementById('resetTotalSpaces').addEventListener('click', function() {
    document.getElementById('totalSpacesInput').value = '';
    chrome.storage.local.remove('userTotalSpaces', function() {
      console.log('Total spaces input reset.');
      // Recalculate and update the UI to reflect the reset
      chrome.storage.local.get(['spaceData', 'avgCrackedDrops'], function(storageData) {
        const spaceData = storageData.spaceData || [];
        const avgCrackedDrops = storageData.avgCrackedDrops || 1;
        // updatePotentialRevenue(spaceData, avgCrackedDrops);
        document.getElementById('totalSpaces').textContent = `Spaces:${spaceData.length}`;
        const wardensNeeded = calculateWardensNeeded(spaceData.length);
        chrome.storage.local.get('timeWardenTotalItems', function(data) {
          const timeWardenTotalItems = data.timeWardenTotalItems || 0;
          const wardensNeededText = calculateWardensNeededText(wardensNeeded, timeWardenTotalItems);
          document.getElementById('wardensNeeded').textContent = wardensNeededText;
        });
      });
    });
  });
  const helpButton = document.getElementById('helpButton');
  helpButton.textContent = 'Show Help'; // Set initial text for the help button
  helpButton.addEventListener('click', toggleHelpVideo);
  document.getElementById('heading').addEventListener('click', refreshDataAndInitPopup);
  const saveAvgCrackedDropsButton = document.getElementById('saveAvgCrackedDrops');
  saveAvgCrackedDropsButton.addEventListener('click', function() {
    const newAvgCrackedDrops = parseFloat(document.getElementById('avgCrackedDropsInput').value);
    chrome.storage.local.set({'avgCrackedDrops': newAvgCrackedDrops}, function() {
      console.log('Average drops updated.');
      chrome.storage.local.get('spaceData', function(storageData) {
        window.avgCrackedDrops = newAvgCrackedDrops;
        // updatePotentialRevenue(storageData.spaceData);
      });
    });
  });
  // Prevent clicks within the config panel from closing it
  const configPanelInputs = document.querySelectorAll('#configPanel input');
  configPanelInputs.forEach(input => {
    input.addEventListener('click', function(event) {
      event.stopPropagation();
    });
  });
  setInputValuesToCurrentSettings(); // Set the input values to the current settings
}
